package model.characters;

public enum Direction {
     UP,
     DOWN,
     LEFT,
     RIGHT,
}
