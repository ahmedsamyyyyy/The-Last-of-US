package model.characters;

public class Explorer extends Hero{
     public Explorer(String name, int maxHp, int attackDmg, int maxActions){
       	 super(name,maxHp,attackDmg,maxActions);
     }  	 
}
