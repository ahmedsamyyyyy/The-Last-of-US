package model.collectibles;

public interface Collectible {

}
