package engine;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

import model.characters.Explorer;
import model.characters.Fighter;
import model.characters.Hero;
import model.characters.Medic;
import model.characters.Zombie;
import model.world.Cell;



public class Game {
	static ArrayList<Hero> availableHeroes;
	 static ArrayList<Hero> heroes;
	 static ArrayList<Zombie> zombies;
	 static Cell [][] map;
	 
	 public static void loadHeroes(String filePath) throws  IOException {
		String line=" ";
		String t=",";
		 @SuppressWarnings("resource")
		 
		 BufferedReader br = new BufferedReader(new FileReader(filePath)) ;

		 
		 while((line=br.readLine())!=null) {
			 String [] values = line.split(t);			 
			 if (values[1]=="EXP") {
				 availableHeroes.add(new Explorer(values[0],Integer.parseInt(values[2]),Integer.parseInt(values[3]),Integer.parseInt(values[4])));
			 }
			 else if (values[1]=="FIGH") {
				 availableHeroes.add(new Fighter(values[0],Integer.parseInt(values[2]),Integer.parseInt(values[3]),Integer.parseInt(values[4])));
			 }
			 else if (values[1]=="MED") {
				 availableHeroes.add(new Medic(values[0],Integer.parseInt(values[2]),Integer.parseInt(values[3]),Integer.parseInt(values[4])));
			 }
			 
			 
			 
		 }
		 
		 
	 }

}
